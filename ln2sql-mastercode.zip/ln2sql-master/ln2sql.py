#!/usr/bin/python
# -*- coding: utf-8 -*

import os, sys, getopt
import unicodedata

from Database import Database
from LangConfig import LangConfig
from Parser import Parser
from Thesaurus import Thesaurus
from StopwordFilter import StopwordFilter

reload(sys)
sys.setdefaultencoding("utf-8")

 

class sql_ln2sql:

    @staticmethod
    def new1( user_name , password , database ,input_sentence):
         #import os
         myCmd = 'mysqldump -u' +user_name +' -p  -hlocalhost --no-data ' + database +'> database.sql'
         print myCmd
         os.system(myCmd)
         return ln2sql.new2("/home/keerti-yalasangimath/Downloads/nlq2sql/ln2sql-master/database.sql",input_sentence)


class ln2sql:

    def __init__(self):
        print "never called in this case"
   
    @staticmethod
    def new2(database_path, input_sentence):
        database = Database()
        database.load(database_path)
        database.print_me()

     

        language_path = "/home/keerti-yalasangimath/Downloads/nlq2sql/ln2sql-master/lang/english.csv"
        config = LangConfig()
        config.load(language_path)
        
        parser = Parser(database, config)

        thesaurus_path = "/home/keerti-yalasangimath/Downloads/nlq2sql/ln2sql-master/thesaurus/th_english.dat"
        thesaurus = Thesaurus()
        thesaurus.load(thesaurus_path)
        parser.set_thesaurus(thesaurus)

        queries = parser.parse_sentence(input_sentence)

        result=""
        for query in queries:
            result+=str(query)
            print query

        return result


def print_help_message():
    print '\n'
    print 'Usage:'
    print '\tpython ln2sql.py -d <path> -i <input-sentence> '
    print 'Parameters:'
    print '\t-h\t\t\tprint this help message'
    print '\t-d <path>\t\tpath to SQL dump file' 
    print '\t-i <input-sentence>\tinput sentence to parse' 
    print '\n'

def main(argv):
    try:
        opts, args = getopt.getopt(argv,"d:i:")
        database_path = None
        input_sentence = None
         

        for i in range(0, len(opts)):
            if opts[i][0] == "-d":
                database_path = opts[i][1] 
            elif opts[i][0] == "-i":
                input_sentence = opts[i][1] 
            else:
                print_help_message()
                sys.exit()

        if (database_path is None) or (input_sentence is None):
            print_help_message()
            sys.exit()
        
        sql_ln2sql(str(user_name),str(password),str(database),str(input_sentence))
        ln2sql(str(database_path), str(input_sentence))
        

    except getopt.GetoptError:
        print_help_message()
        sys.exit()

if __name__ == '__main__':
    main(sys.argv[1:])
