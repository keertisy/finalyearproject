from Tkinter import *
import tkFileDialog
from tkMessageBox import *
from ln2sql import ln2sql
from ln2sql import sql_ln2sql
import sys
import unicodedata
import os


reload(sys)
sys.setdefaultencoding("utf-8")

class App:
	def __init__(self, root):
		root.title('ln2sql')
		root.bind('<Return>', self.parse)

		self.db_user_frame = LabelFrame(root, text="Data Base Details", padx=50, pady=10)
		self.db_user_frame.pack(fill="both", expand="yes", padx=10, pady=5)
                
		self.db_user_path_label = Label(self.db_user_frame, text="User Name")
		self.db_user_path_label.pack(side="left")

		self.dbu_input_string = StringVar() 
		self.dbu_input_string.set("Enter name...")
		self.dbu_input_entry = Entry(self.db_user_frame, textvariable=self.dbu_input_string, width=20)
		self.dbu_input_entry.pack(side="right")
                self.dbu_input_entry.bind('<Button-1>', self.clearu)
############################

		self.db_pw_frame = LabelFrame(root, text="", padx=50, pady=10)
		self.db_pw_frame.pack(fill="both", expand="yes", padx=10, pady=5)


		self.db_pw_path_label = Label(self.db_pw_frame, text="Password")
		self.db_pw_path_label.pack(side="left")

		self.dbp_input_string = StringVar() 
		self.dbp_input_string.set("Enter password...")
		self.dbp_input_entry = Entry(self.db_pw_frame,show="*", textvariable=self.dbp_input_string, width=20)
		self.dbp_input_entry.pack(side="right")
                self.dbp_input_entry.bind('<Button-1>', self.clearp)
		
############################

		self.db_frame = LabelFrame(root, text="", padx=50, pady=10)
		self.db_frame.pack(fill="both", expand="yes", padx=10, pady=5)
                
		self.db_path_label = Label(self.db_frame, text="db Name")
		self.db_path_label.pack(side="left")

		self.db_input_string = StringVar() 
		self.db_input_string.set("Enter database...")
		self.db_input_entry = Entry(self.db_frame, textvariable=self.db_input_string, width=20)
		self.db_input_entry.pack(side="right")
		self.db_input_entry.bind('<Button-1>', self.cleardb)

###########################

		self.sentence_frame = LabelFrame(root, text="Input Sentence", padx=50, pady=10)
		self.sentence_frame.pack(fill="both", expand="yes", padx=10, pady=5)

		self.input_sentence_string = StringVar() 
		self.input_sentence_string.set("Enter a sentence...")
		self.input_sentence_entry = Entry(self.sentence_frame, textvariable=self.input_sentence_string, width=80)
		self.input_sentence_entry.pack()
		self.input_sentence_entry.bind('<Button-1>', self.clearEntry)


##############################



		self.r_frame = LabelFrame(root, text="Result", padx=50, pady=10)
		self.r_frame.pack(fill="both", expand="yes", padx=10, pady=5)
	
		self.r_sentence_string = StringVar() 
		self.r_sentence_string.set("")
		self.r_sentence_entry = Entry(self.r_frame, textvariable=self.r_sentence_string, width=80)
		self.r_sentence_entry.pack()
		
##############################



		self.fr_frame = LabelFrame(root, text="Result", padx=50, pady=10)
		self.fr_frame.pack(fill="both", expand="yes", padx=10, pady=5)
                #self.text=Text(self.fr_frame,width=80,heigth=50)  
                #+self.text.pack() 
                
		self.fr_sentence_string = StringVar() 
		self.fr_sentence_string.set("")
                         
 
		self.fr_sentence_entry = Entry(self.fr_frame, textvariable=self.fr_sentence_string, width=80)
		self.fr_sentence_entry.pack()
                

###############################

		#self.output_button = Button(root, text="Output",command=self.output_window)
		#self.output_button.pack(side="right", fill="both", expand="yes", padx=10, pady=2)


		 

#####################################################

		self.go_button = Button(root, text="Go!", command=self.lanch_parsing)
		self.go_button.pack(side="right", fill="both", expand="yes", padx=10, pady=2)

		self.reset_button = Button(root, text="Reset", command=self.reset_window)
		self.reset_button.pack(side="right", fill="both", expand="yes", padx=10, pady=2)



	def clearEntry(self, event):
		self.input_sentence_string.set("")
	def clearu(self, event):
                self.dbu_input_string.set("")
	def clearp(self, event):
                self.dbp_input_string.set("")
	def cleardb(self, event):
                self.db_input_string.set("")
	

	def parse(self, event):
		self.lanch_parsing()

	 
		 
		 

	def reset_window(self):
		self.input_sentence_string.set("Enter a sentence...")
                self.dbu_input_string.set("Enter name...")
                self.dbp_input_string.set("Enter password...")
                self.db_input_string.set("Enter database...")
                self.r_sentence_string.set("")
                self.fr_sentence_string.set("")
		return

	def lanch_parsing(self):
		try:
			 
		 result = sql_ln2sql.new1(self.dbu_input_string.get(),  self.dbp_input_string.get(), self.db_input_string.get(), self.input_sentence_string.get())
                 #print result
                 self.r_sentence_string.set(unicode(result, "utf-8"))
                 self.r_sentence_entry.pack()
                 final_result_str = final_result.new3(self.dbu_input_string.get(),  self.dbp_input_string.get(), self.db_input_string.get(),result)
                 print final_result_str
                  
                 self.fr_sentence_string.set(unicode(final_result_str, "utf-8"))
                 self.fr_sentence_entry.pack()


                  
                  
		except Exception, e:
			showwarning('Error', e)
		return

class final_result:

    @staticmethod
    def new3( user_name , password_entered , databasename ,result):
          
         import MySQLdb
         from mysql.connector import Error
         try:
            mySQLconnection = MySQLdb.connect(host='localhost',
                             database=databasename,
                             user=user_name,
                             password=password_entered)
            print("connection sussessfull")
            
            sql_select_Query = result
            
            cursor = mySQLconnection .cursor()
            cursor.execute(sql_select_Query)
            records = cursor.fetchall()
            print records
            print "Total number of rows in python_developers is - ", cursor.rowcount
            print "Printing each row's column values i.e.  developer record"
            import csv
            with open('output_file.txt', 'w') as f:
                 writer = csv.writer(f,delimiter='\t' ,lineterminator='\n') 
                 title = [i[0] for i in cursor.description]
                 writer.writerow(title) 
                 for row in records:
                     writer.writerow(row) 

            cursor.close()
            mySQLconnection.commit()
            mySQLconnection.close()
            print("MySQL connection is closed")

            data = ""
	    with open('output_file.txt', 'r') as file:
                 data = file.read()
                  
         except Error as e :
            print ("Error while connecting to MySQL", e)
        
         return data


root = Tk()
App(root)
root.resizable(width=FALSE, height=FALSE)
root.mainloop()
